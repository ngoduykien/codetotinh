<?
  define('DB_SERVER', 'localhost');
  define('DB_SERVER_USERNAME', 'pok');
  define('DB_SERVER_PASSWORD', '123');
  define('DB_DATABASE', 'pok');
  define('ADMIN_USERS', 'admin');
// Additional administrators can be added by seperating admin usernames with commas.
?>